<?php

class CorrectController extends Controller {
	public function actionIndex() {
		
		
	}
	
	public function actionSchool($id) {
		
		
	}
	
	public function actionCity($id) {
		
		
		
	}
	
	public function actionUpload($id) {
		
		
	}
	
}