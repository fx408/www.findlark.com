<div id="book-list">
	
</div>

<pre class="loading" id="load-more">
	<strong>点击加载更多...</strong>
</pre>

<script type="text/javascript" src="/static/douban/app.js"></script>