<div class="reading-title"><?php echo $title;?></div>
<pre class="reading-content"><?php echo $data;?></pre>