<form>
	<input type="text" name="keyword" value="">
	
	<select name="from">
		<option value="sina">新浪爱问</option>
	</select>
	<input type="submit" value="查询">
</form>