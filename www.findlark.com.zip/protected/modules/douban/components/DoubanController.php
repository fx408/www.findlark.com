<?php
class DoubanController extends Controller{
	public $title = '手机上的豆瓣';
	public $bookid = 0;
	
}