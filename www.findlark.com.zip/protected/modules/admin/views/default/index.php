<div>
	<a href="/admin/tool/index">扩展</a>
	<a href="/admin/image/index">图片</a>
	<a href="/admin/mark/index">标记</a>
	<a href="/admin/blog/index">博文</a>
</div>