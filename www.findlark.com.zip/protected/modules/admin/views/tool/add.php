<form action="" method="post">
	标题:<input type="text" name="Form[title]"><br>
	路径:<input type="text" name="Form[path]"><br>
	快照:<input type="text" name="Form[thumb]"><br>
	
	<input type="submit" value="提交">
</form>

<div>
	<a href="/admin/tool/index">列表</a>
</div>