<?php

class MyController extends SController{
	
	
	
	
	
}