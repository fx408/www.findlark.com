<?php

class ListController extends Controller {
	public function actionIndex() {
		
		
	}
	
	public function actionCity() {
		
		
		
	}
	
}