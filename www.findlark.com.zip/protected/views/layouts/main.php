<?php $this->beginContent('//layouts/public'); ?>
<?php echo $content; ?>
<?php $this->endContent(); ?>